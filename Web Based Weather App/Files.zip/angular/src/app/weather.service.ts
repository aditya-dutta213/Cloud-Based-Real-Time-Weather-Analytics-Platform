import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class WeatherService {
  private apiUrl = 'https://backend-dot-weather-search-project.wl.r.appspot.com/get_weather';  //  URL for the backend

  constructor(private http: HttpClient) {}

  getWeather(city: string, state: string): Observable<any> {
    const params = new HttpParams()
      .set('city', city)
      .set('state', state);

    return this.http.get<any>(this.apiUrl, { params });
  }
  addFavorite(city: string, state: string) {
    const url = 'https://backend-dot-weather-search-project.wl.r.appspot.com/add_favorite';
    return this.http.post(url, { city, state });
  }
  
  removeFavorite(city: string, state: string) {
    const url = 'https://backend-dot-weather-search-project.wl.r.appspot.com/delete_favorite';
    return this.http.delete(url, { body: { city, state } });
  }
  getFavorites() {
    const url = 'https://backend-dot-weather-search-project.wl.r.appspot.com/favorites';
    return this.http.get<any[]>(url);
  }
  
}
