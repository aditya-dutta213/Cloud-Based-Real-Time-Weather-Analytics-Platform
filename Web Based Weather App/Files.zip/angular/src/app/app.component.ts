import { Component } from '@angular/core';
import { WeatherService } from './weather.service';
import { FormControl, FormGroup, Validators, FormsModule, ReactiveFormsModule, AbstractControl } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatOptionModule } from '@angular/material/core';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { NgFor, NgIf, AsyncPipe, CommonModule } from '@angular/common';
import { Observable, map, startWith } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
import { ChangeDetectorRef } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import * as Highcharts from 'highcharts';
import highchartsMore from 'highcharts/highcharts-more';
import windbarbModule from 'highcharts/modules/windbarb';
import { AfterViewInit } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { trigger, transition, style, animate } from '@angular/animations';

declare var google: any; 

highchartsMore(Highcharts);
windbarbModule(Highcharts);

interface Forecast {
  date: string;
  status: string;
  weatherCode: number;  
  tempHigh: number;
  tempLow: number;
  windSpeed: number | string;
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    FormsModule,
    ReactiveFormsModule,
    MatAutocompleteModule,
    MatFormFieldModule,
    MatInputModule,
    MatOptionModule,
    NgFor,
    NgIf,
    AsyncPipe,
    HttpClientModule,
    CommonModule
  ],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  animations: [
    trigger('slideAnimation', [
      transition(':enter', [
        style({ transform: 'translateX(100%)' }), 
        animate('300ms ease-out', style({ transform: 'translateX(0)' })) 
      ]),
      transition(':leave', [
        style({ transform: 'translateX(0)' }),
        animate('300ms ease-in', style({ transform: 'translateX(100%)' })) 
      ])
    ])
  ]
})
export class AppComponent implements AfterViewInit {
  title = 'weather-search';
  weatherData: any = null;  
  errorMessage: string = '';  
  isFavorite: boolean = false;
  showFavorites: boolean = false; 
  favorites: any[] = []; 
  hourlyData: any[] = []; 

  isLoading: boolean = false; 

  showDetailsPane: boolean = false; 
  selectedDate: string = ''; 
  detailsData: any = null; 


  selectedTab: string = 'dayView';
  
  lat: number | undefined;
  lon: number | undefined;

  ngAfterViewInit() {
    // Initialize the temperature range chart if the selected tab is 'tempChart'
    if (this.selectedTab === 'tempChart') {
      this.renderTemperatureRangeChart();
    }
  }
  

  setTab(tabName: string) {
    this.selectedTab = tabName;
    if (tabName === 'tempChart') {
        setTimeout(() => this.renderTemperatureRangeChart(), 0); 
    }
    else if (tabName === 'meteogram') {
      console.log("Meteogram tab selected");
      setTimeout(() => this.renderMeteogramChart(), 0); 
    }
  }

  forecastData: Forecast[] = [];  

  form = new FormGroup({
    street: new FormControl('', { validators: [Validators.required, this.noWhitespaceValidator], nonNullable: true }),
    city: new FormControl('', { validators: [Validators.required, this.noWhitespaceValidator], nonNullable: true }),
    state: new FormControl('', { validators: [Validators.required], updateOn: 'blur', nonNullable: true })
  });

  noWhitespaceValidator(control: AbstractControl): { whitespace: boolean } | null {
    const isValid = control.value && control.value.trim().length > 0;
    return isValid ? null : { whitespace: true };
  }
  
  
  formValid = false;  
  filteredCitiesSubject = new BehaviorSubject<string[]>([]);  
  filteredCities: Observable<string[]> = this.filteredCitiesSubject.asObservable();
  filteredStates!: Observable<string[]>;
  autoCompleteResults: { city: string; stateAbbreviation: string }[] = [];
  isCitySelected = false;

  
  stateMap: Record<string, string> = {
    'AL': 'Alabama', 'AK': 'Alaska', 'AZ': 'Arizona', 'AR': 'Arkansas', 'CA': 'California',
    'CO': 'Colorado', 'CT': 'Connecticut', 'DE': 'Delaware', 'FL': 'Florida', 'GA': 'Georgia',
    'HI': 'Hawaii', 'ID': 'Idaho', 'IL': 'Illinois', 'IN': 'Indiana', 'IA': 'Iowa',
    'KS': 'Kansas', 'KY': 'Kentucky', 'LA': 'Louisiana', 'ME': 'Maine', 'MD': 'Maryland',
    'MA': 'Massachusetts', 'MI': 'Michigan', 'MN': 'Minnesota', 'MS': 'Mississippi', 'MO': 'Missouri',
    'MT': 'Montana', 'NE': 'Nebraska', 'NV': 'Nevada', 'NH': 'New Hampshire', 'NJ': 'New Jersey',
    'NM': 'New Mexico', 'NY': 'New York', 'NC': 'North Carolina', 'ND': 'North Dakota', 'OH': 'Ohio',
    'OK': 'Oklahoma', 'OR': 'Oregon', 'PA': 'Pennsylvania', 'RI': 'Rhode Island', 'SC': 'South Carolina',
    'SD': 'South Dakota', 'TN': 'Tennessee', 'TX': 'Texas', 'UT': 'Utah', 'VT': 'Vermont',
    'VA': 'Virginia', 'WA': 'Washington', 'WV': 'West Virginia', 'WI': 'Wisconsin', 'WY': 'Wyoming'
  };
  allStates = Object.values(this.stateMap);

  constructor(private http: HttpClient, private cdr: ChangeDetectorRef, private weatherService: WeatherService) {}

  ngOnInit() {
    this.loadFavorites(); 

    this.form.controls['city'].valueChanges.pipe(
      startWith('')
    ).subscribe(value => {
      this.isCitySelected = false;  
      this._filterCities(value || '');  
    });
  
    this.filteredStates = this.form.controls['state'].valueChanges.pipe(
      startWith(''),
      map(value => this._filterStates(value || ''))
    );
    
    this.form.valueChanges.subscribe(() => {
      this.formValid = this.form.valid;
    });
  }
  
  // Helper function to filter states based on user input
  private _filterStates(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this.allStates.filter(state => state.toLowerCase().includes(filterValue));
}

  private _filterCities(value: string): void {
    if (value.length >= 1 && !this.isCitySelected) {  
      this.fetchCitySuggestions(value);
    }
  }
  
  fetchCitySuggestions(input: string) {
    const url = `https://backend-dot-weather-search-project.wl.r.appspot.com/proxy?input=${input}`;

    this.filteredCitiesSubject.next([]);

    this.http.get<any>(url).subscribe({
      next: (response) => {
      console.log('API Response:', response);  
  
      if (response && response.predictions) {
        this.autoCompleteResults = response.predictions.map((prediction: any) => {
          const city = prediction.terms[0].value;
          const stateAbbreviation = prediction.terms[1].value;
          return { city, stateAbbreviation };
        });

        this.filteredCitiesSubject.next(this.autoCompleteResults.map(result => result.city));
        this.cdr.detectChanges();
      } else {
        console.error('No predictions found');
        this.filteredCitiesSubject.next([]);
      }
    },
    error: (error) => {
      console.error('Error fetching autocomplete data:', error);
      this.filteredCitiesSubject.next([]); 
    }
    });
  }

  handleCitySelection() {
    const selectedCity = this.form.controls['city'].value;
    console.log('Selected city:', selectedCity);
  
    const selectedResult = this.autoCompleteResults.find(result => result.city === selectedCity);
    console.log('Matched result:', selectedResult);
  
    if (selectedResult) {
      const fullStateName = this.stateMap[selectedResult.stateAbbreviation] || selectedResult.stateAbbreviation;
      console.log('Setting state to:', fullStateName);
  
      if (!this.isCitySelected) {
        this.form.controls['state'].setValue(fullStateName);
      }
  
      this.isCitySelected = true;
      this.cdr.detectChanges();
    } else {
      console.warn('No matching result found for city:', selectedCity);
    }
  }

  checkIfFavorite() {
    const city = this.form.controls['city'].value;
    const state = this.form.controls['state'].value;
  
    this.isFavorite = this.favorites.some(fav => fav.city === city && fav.state === state);
  }
  

  toggleFavorite() {
  
    this.isFavorite = !this.isFavorite;
  
    if (this.isFavorite) {
      this.addToFavorites();
    } else {
      this.removeFromFavorites();
    }
  }

  addToFavorites() {
    const city = this.form.controls['city'].value;
    const state = this.form.controls['state'].value;
  
    // Send a POST request to add the city to favorites
    this.weatherService.addFavorite(city, state).subscribe({
      next: () => {
        console.log(`${city}, ${state} added to favorites`);
      },
      error: (error) => {
        console.error("Error adding to favorites:", error);
      }
    });
  }
  
  removeFromFavorites() {
    const city = this.form.controls['city'].value;
    const state = this.form.controls['state'].value;
  
    // Send a DELETE request to remove the city from favorites
    this.weatherService.removeFavorite(city, state).subscribe({
      next: () => {
        console.log(`${city}, ${state} removed from favorites`);
      },
      error: (error) => {
        console.error("Error removing from favorites:", error);
      }
    });
  }

  // Toggle between showing the Favorites table and the weather results
  toggleFavoritesView() {
    this.showFavorites = !this.showFavorites;

    if (this.showFavorites) {
      this.loadFavorites();  
    }
  }
  showResults() {
    this.showFavorites = false;  
    this.selectedTab = 'dayView';
  }
  

  // Fetch the list of favorites from the backend
  loadFavorites() {
    this.weatherService.getFavorites().subscribe({
      next: (data) => {
        this.favorites = data;
        console.log("Fetched favorites:", this.favorites);
      },
      error: (error) => {
        console.error("Error fetching favorites:", error);
      }
    });
  }
  removeFavorite(city: string, state: string) {
    this.weatherService.removeFavorite(city, state).subscribe({
      next: () => {
        console.log(`${city}, ${state} removed from favorites`);
        this.loadFavorites();  

        if (this.weatherData && this.weatherData.city === city && this.weatherData.state === state) {
          this.isFavorite = false;
        }
      },
      error: (error) => {
        console.error("Error removing favorite:", error);
      }
    });
  }
  

  // Load weather details for a specific city and state from the Favorites table
  loadWeather(city: string, state: string) {
    this.form.controls['city'].setValue(city);
    this.form.controls['state'].setValue(state);
    this.onSearch();  

    this.showFavorites = false;  
    this.selectedTab = 'dayView';  
  }
  
   
  onSearch() {
      // Get the city and state values from the form controls
      const city = this.form.controls['city'].value;
      const state = this.form.controls['state'].value;

      if (city && state) {
          this.checkIfFavorite(); 
          this.isFavorite = this.favorites.some(fav => fav.city === city && fav.state === state);

          this.isLoading = true;

          this.weatherService.getWeather(city, state).subscribe({
              next: (data) => {

                  this.isLoading = false;

                  console.log("Latitude from backend:", data.lat);
                  console.log("Longitude from backend:", data.lon);

                  // Populate weatherData with full response and add city/state
                  this.weatherData = {
                      ...data,          
                      city: city,       
                      state: state      
                  };
                  this.errorMessage = '';  

                  this.lat = data.lat;
                  this.lon = data.lon;

                  setTimeout(() => {
                      const mapDiv = document.getElementById('map');
                      if (mapDiv) {
                          this.initializeMap(this.lat as number, this.lon as number);
                      } else {
                          console.warn("Map div is not ready yet.");
                      }
                  }, 500);  


                  // Extract forecast data for the next 6 days
                  if (data && data.data && data.data.timelines && data.data.timelines[0].intervals) {
                    this.forecastData = data.data.timelines[0].intervals.slice(0, 6).map((interval: any) => ({
                      date: new Date(interval.startTime).toLocaleDateString('en-GB', {
                        weekday: 'long',
                        day: '2-digit',
                        month: 'short',
                        year: 'numeric'
                      }),
                      status: this.getWeatherStatus(interval.values.weatherCode),
                      weatherCode: interval.values.weatherCode, 
                      tempHigh: parseFloat(interval.values.temperatureMax) || 0,  
                      tempLow: parseFloat(interval.values.temperatureMin) || 0,    
                      windSpeed: interval.values.windSpeed ? interval.values.windSpeed.toFixed(2) : '--',
                      apparentTemperature: interval.values.temperatureApparent || 'N/A',
                      sunriseTime: interval.values.sunriseTime || 'N/A',
                      sunsetTime: interval.values.sunsetTime || 'N/A',
                      humidity: interval.values.humidity || 'N/A',
                      visibility: interval.values.visibility || 'N/A',
                      cloudCover: interval.values.cloudCover || 'N/A'
                    }));
                  } else {
                    this.forecastData = [];  
                  }
                  // Extract hourly data for the Meteogram chart
                  const hourlyTimeline = data.data.timelines.find((timeline: any) => timeline.timestep === '1h');
                  this.hourlyData = hourlyTimeline ? hourlyTimeline.intervals : [];

                  if (this.selectedTab === 'meteogram' && this.hourlyData.length > 0) {
                    this.renderMeteogramChart();
                  }
              },
              error: (error) => {
                  this.isLoading = false;
                  console.error("Error fetching weather data:", error);
                  this.errorMessage = "Failed to fetch weather data. Please try again.";  
                  this.weatherData = null; 
              }
          });
      } else {
          this.errorMessage = "Please enter both city and state.";
          this.weatherData = null;
          this.forecastData = [];
      }
  }

  getIconFileName(weatherCode: number): string {
    const weatherIcons: { [key: number]: string } = {
      1000: "clear_day.svg",
      1001: "cloudy.svg",
      1100: "mostly_clear_day.svg",
      1101: "partly_cloudy_day.svg",
      1102: "mostly_cloudy.svg",
      2000: "fog.svg",
      2100: "fog_light.svg",
      3000: "light_wind.png",
      3001: "wind.png",
      3002: "strong_wind.png",
      4000: "drizzle.svg",
      4200: "rain_light.svg",
      4001: "rain.svg",
      4201: "rain_heavy.svg",
      5000: "snow.svg",
      5100: "snow_light.svg",
      5001: "flurries.svg",
      5101: "snow_heavy.svg",
      6000: "freezing_drizzle.svg",
      6001: "freezing_rain.svg",
      6200: "freezing_rain_light.svg",
      6201: "freezing_rain_heavy.svg",
      7000: "ice_pellets.svg",
      7101: "ice_pellets_heavy.svg",
      7102: "ice_pellets_light.svg",
      8000: "tstorm.svg"
    };
    return weatherIcons[weatherCode] || "default_icon.svg"; 
  }
  
  getWeatherStatus(weatherCode: number): string {
    const weatherDescriptions: { [key: number]: string } = {
      1000: "Clear",
      1001: "Cloudy",
      1100: "Mostly Clear",
      1101: "Partly Cloudy",
      1102: "Mostly Cloudy",
      2000: "Fog",
      2100: "Light Fog",
      3000: "Light Wind",
      3001: "Windy",
      3002: "Strong Wind",
      4000: "Drizzle",
      4200: "Light Rain",
      4001: "Rain",
      4201: "Heavy Rain",
      5000: "Snow",
      5100: "Light Snow",
      5001: "Flurries",
      5101: "Heavy Snow",
      6000: "Freezing Drizzle",
      6001: "Freezing Rain",
      6200: "Light Freezing Rain",
      6201: "Heavy Freezing Rain",
      7000: "Ice Pellets",
      7101: "Heavy Ice Pellets",
      7102: "Light Ice Pellets",
      8000: "Thunderstorm"
    };
    return weatherDescriptions[weatherCode] || "Unknown Condition";
  }

  renderTemperatureRangeChart() {
    console.log("Forecast Data:", this.forecastData);
      Highcharts.chart('temp-range-chart', {
          chart: {
              type: 'arearange',
              zoomType: 'x' as any  
          },
          title: {
              text: 'Temperature Ranges (Min, Max)'
          },
          xAxis: {
              categories: this.forecastData.map(day =>
                  new Date(day.date).toLocaleDateString('en-GB', {
                      day: '2-digit',
                      month: 'short'
                  })
              ),
              tickmarkPlacement: 'on'
          },
          yAxis: {
              title: {
                  text: 'Temperature (°F)'
              }
          },
          tooltip: {
              shared: true,
              valueSuffix: '°F'
          },
          series: [{
              type: 'arearange',
              name: 'Temperatures',
              data: this.forecastData.map(day => [day.tempLow, day.tempHigh]), 
              color: {
                  linearGradient: { x1: 0, y1: 1, x2: 0, y2: 0 },
                  stops: [
                      [0, '#c4e4fa'],
                      [1, '#f89c21']
                  ]
              },
              fillOpacity: 0.5,
              marker: {
                  enabled: true,
                  fillColor: '#26a5fc',
                  lineWidth: 2,
                  lineColor: '#26a5fc'
              }
          }]
      } as Highcharts.Options);
  }

  
  renderMeteogramChart() {
      import('highcharts/modules/windbarb').then(module => {
          const windbarb = module.default || module;
          windbarb(Highcharts);

          const self = this;

          const hours = self.hourlyData.map((entry: any) =>
              new Date(entry.startTime).getHours()
          );
          const temperatures = self.hourlyData.map((entry: any) => entry.values.temperature);
          const humidity = self.hourlyData.map((entry: any) => entry.values.humidity);
          const windSpeeds = self.hourlyData.map((entry: any) => entry.values.windSpeed);
          const windDirections = self.hourlyData.map((entry: any) => entry.values.windDirection);
          const pressure = self.hourlyData.map((entry: any) => entry.values.pressureSeaLevel);

          Highcharts.chart('hourly-weather-chart', {
              chart: {
                  type: 'spline',
                  zoomType: 'x',
                  backgroundColor: 'white',
                  width: null,
                  height: 300
              },
              title: {
                  text: 'Hourly Weather (For Next 5 Days)'
              },
              legend: {
                  enabled: false
              },
              xAxis: [{
                  categories: hours.map(String),
                  tickInterval: 6,
                  crosshair: true,
                  gridLineWidth: 1,
                  gridLineColor: '#cccccc',
                  lineWidth: 2,
                  lineColor: '#333',
                  tickWidth: 1, 
                  tickColor: '#333',
                  labels: {
                      format: '{value}',
                      rotation: 0
                  }
              }, {
                  categories: hours.map(String),
                  tickInterval: 2,
                  linkedTo: 0,
                  opposite: false,
                  lineWidth: 0,
                  labels: {
                      enabled: false
                  }
              }] as Highcharts.XAxisOptions[],
              yAxis: {
                  title: {
                      text: null
                  },
                  min: 0,
                  max: 100,
                  tickInterval: 7,
                  labels: {
                      format: '{value}°',
                      style: {
                          fontSize: '8px',
                          fontWeight: 'bold'
                      }
                  }
              },
              tooltip: {
                  shared: true,
                  formatter: function () {
                      if (!this.points || !this.points[0] || this.points[0].point.index === undefined) {
                          return 'No data available';
                      }

                      const index = this.points[0].point.index;
                      if (!self.hourlyData || !self.hourlyData[index]) {
                          return 'No data available';
                      }

                      const startTime = self.hourlyData[index].startTime;
                      const date = new Date(startTime);

                      if (isNaN(date.getTime())) {
                          return 'Invalid Date';
                      }

                      const formattedDate = date.toLocaleDateString('en-GB', {
                          weekday: 'long',
                          day: '2-digit',
                          month: 'short'
                      });
                      const formattedTime = date.toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit'
                      });

                      let tooltip = `<b>${formattedDate}, ${formattedTime}</b><br/>`;
                      this.points.forEach(point => {
                          const suffix = (point.series as any).userOptions.tooltip?.valueSuffix || '';
                          if (point.series.name !== 'Wind') {
                              tooltip += `<span style="color:${point.color}">\u25CF</span> ${point.series.name}: ${point.y}${suffix}<br/>`;
                          }
                      });
                      tooltip += `<span style="color:#4945bb">\u25CF</span> Wind Speed: ${windSpeeds[index]} mph<br/>`;
                      return tooltip;
                  }
              },
              series: [{
                  name: 'Temperature',
                  type: 'spline',
                  data: temperatures,
                  tooltip: { valueSuffix: ' °F' },
                  color: '#f92a2b',
                  zIndex: 3,
                  marker: { enabled: false },
                  lineWidth: 2
              }, {
                  name: 'Humidity',
                  type: 'column',
                  data: humidity,
                  tooltip: { valueSuffix: '%' },
                  color: '#7cc6fe',
                  zIndex: 1,
                  pointPadding: 0,
                  pointWidth: 4,
                  borderWidth: 0,
                  dataLabels: {
                      enabled: true,
                      color: '#000000',
                      format: '{y:.0f}',
                      style: { fontSize: '6px', fontWeight: 'bold' }
                  }
              }, {
                  name: 'Air Pressure',
                  type: 'spline',
                  data: pressure,
                  tooltip: { valueSuffix: ' inHg' },
                  color: '#f8b041',
                  zIndex: 2,
                  lineWidth: 2,
                  dashStyle: 'ShortDot'
              }, {
                  type: 'windbarb',
                  name: 'Wind',
                  data: windDirections.map((direction, i) => {
                        if (i % 2 === 0) {
                          return {
                              value: windSpeeds[i],
                              direction: direction
                          };
                      } else {
                          return { value: null };  
                      }
                  }).filter(point => point !== null),  
                  tooltip: { enabled: false },
                  color: '#4c47b3',
                  vectorLength: 8,
                  yOffset: 11
              }]
          } as Highcharts.Options);
      }).catch(error => {
          console.error('Failed to load windbarb module:', error);
      });
  }

  // Method to handle the Details button click
  onDetailsButtonClick() {
    if (this.detailsData) {
      this.showDetailsPane = true;

      setTimeout(() => {
        const mapDiv = document.getElementById('map');
        if (mapDiv && this.lat !== undefined && this.lon !== undefined) {
            this.initializeMap(this.lat as number, this.lon as number);
        } else {
            console.warn("Map div is not ready or coordinates are undefined.");
        }
    }, 500);  


    } else {
      if (this.forecastData.length > 0) {
        const firstRow = this.forecastData[0];
        this.showDetailsPaneForRow(firstRow.date, firstRow);
      }
    }
  }

  // Method to initialize the Google Map
  initializeMap(lat: number, lng: number) {
    const mapOptions = {
      center: { lat: lat, lng: lng },
      zoom: 12, 
    };

    const map = new google.maps.Map(document.getElementById('map'), mapOptions);

    // Add a marker at the specified coordinates
    new google.maps.Marker({
      position: { lat: lat, lng: lng },
      map: map,
      title: "Location",
    });
  }


  // Method to show Details Pane for a specific row
  showDetailsPaneForRow(date: string, values: any) {
    this.selectedDate = date; 
    this.detailsData = {
      status: values.status ,
      temperatureMax: values.tempHigh !== 0 ? values.tempHigh : 'N/A',
      temperatureMin: values.tempLow !== 0 ? values.tempLow : 'N/A',
      apparentTemperature: values.apparentTemperature || 'N/A',
      sunriseTime: new Date(values.sunriseTime).toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true
      }),
      sunsetTime: new Date(values.sunsetTime).toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true
      }),
      humidity: values.humidity || 'N/A',
      windSpeed: values.windSpeed || 'N/A',
      visibility: values.visibility || 'N/A',
      cloudCover: values.cloudCover || 'N/A'
    };
    this.showDetailsPane = true; 

    setTimeout(() => {
      
      console.log("Latitude for map in Details Pane:", this.lat); 
      console.log("Longitude for map in Details Pane:", this.lon); 
  
      if (this.lat !== undefined && this.lon !== undefined && this.lat !== 0 && this.lon !== 0) {
        this.initializeMap(this.lat, this.lon); 
      } else {
        console.warn("Latitude and longitude are still 0 or undefined, map not initialized.");
      }
    }, 100);
  }

  shareOnTwitter() {
    const city = this.weatherData?.city || 'Unknown City';
    const state = this.weatherData?.state || 'Unknown State';
    const date = this.selectedDate || 'Unknown Date';
    const temperature = this.detailsData?.temperatureMax || 'N/A';
    const summary = this.detailsData?.status || 'Unknown Condition';
  
    // ChatGPT Usage (3 lines)
    // Construct the tweet text
    const tweetText = `The temperature in ${city}, ${state} on ${date} is ${temperature}°F and the conditions are ${summary} #CSCI571WeatherForecast`;
  
    // Encode the tweet text for use in a URL
    const encodedText = encodeURIComponent(tweetText);
  
    // Open the Twitter Web Intent in a new tab
    const twitterUrl = `https://twitter.com/intent/tweet?text=${encodedText}`;
    window.open(twitterUrl, '_blank');
  }
  

  // Method to go back to the Results Pane
  backToResults() {
    this.showDetailsPane = false; 
    this.selectedTab = 'dayView';
  }

  onClear() {
    this.form.reset();
    this.isCitySelected = false;
    this.autoCompleteResults = [];

     // Reset the auto-detect location checkbox and enable form fields
    const autoDetectCheckbox = document.getElementById('autodetectLocation') as HTMLInputElement;
    if (autoDetectCheckbox) {
      autoDetectCheckbox.checked = false;
      this.onLocationToggle(); 
    }
     // Clear weather results, hide Favorites table, and reset favorite status
     this.weatherData = null;       
     this.showFavorites = false;    
     this.isFavorite = false;       
     this.showDetailsPane = false; 
  }

  onLocationToggle() {
    const isChecked = (document.getElementById('autodetectLocation') as HTMLInputElement).checked;
  
    if (isChecked) {
      // Clear and disable manual input fields
      this.form.controls['street'].setValue('');
      this.form.controls['city'].setValue('');
      this.form.controls['state'].setValue('');
      this.form.controls['street'].disable();
      this.form.controls['city'].disable();
      this.form.controls['state'].disable();
  
      // Fetch user location using the IPinfo API
      this.http.get('https://ipinfo.io/json?token=77f687734804f6').subscribe({
        next: (data: any) => {

          const [lat, lon] = data.loc.split(',').map(Number);
          console.log("Latitude from IPinfo:", lat); 
          console.log("Longitude from IPinfo:", lon); 

          this.lat = lat;
          this.lon = lon;

          this.weatherData = {
            ...this.weatherData, 
            city: data.city,
            state: data.region,
          };
          console.log("Updated weatherData:", this.weatherData);

          this.form.controls['city'].setValue(data.city);
          this.form.controls['state'].setValue(data.region); 

          this.formValid = true;  
        },
        error: (error) => {
          console.error("Error fetching location:", error);
          alert("Unable to auto-detect location. Please enter manually.");
  
          this.form.controls['street'].enable();
          this.form.controls['city'].enable();
          this.form.controls['state'].enable();
        }
      });
  
    } else {
      this.form.controls['street'].enable();
      this.form.controls['city'].enable();
      this.form.controls['state'].enable();
      this.formValid = this.form.valid;
    }
  }
  

  getFormControl(controlName: string): FormControl {
    return this.form.get(controlName) as FormControl;
  }
}

