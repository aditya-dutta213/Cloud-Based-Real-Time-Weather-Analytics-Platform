
package com.example.weatherapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
import androidx.viewpager2.widget.ViewPager2;

import android.view.Menu;
import android.view.MenuItem;
import androidx.annotation.NonNull;
import android.util.Log;

import org.json.JSONObject;


public class DetailedWeatherActivity extends AppCompatActivity {
    private static final String TAG = "TodayFragment";
    private String city;
    private String state;
    private String temperature;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailed_weather);

        // Retrieve city and state from Intent
        this.city = getIntent().getStringExtra("city");
        this.state = getIntent().getStringExtra("state");
        String weatherData = getIntent().getStringExtra("weatherData");
        Log.d(TAG, "WeatherData received in DetailedWeatherActivity: " + weatherData);

        // Extract temperature from weatherData
        if (weatherData != null) {
            try {
                JSONObject response = new JSONObject(weatherData);
                JSONObject currentWeather = response.getJSONObject("data").getJSONArray("timelines")
                        .getJSONObject(0).getJSONArray("intervals").getJSONObject(0).getJSONObject("values");
                temperature = currentWeather.getDouble("temperature") + "°F";
                Log.d(TAG, "Extracted Temperature: " + temperature);
            } catch (Exception e) {
                Log.e(TAG, "Error parsing weather data: " + e.getMessage(), e);
                temperature = "unknown";
            }
        } else {
            Log.e(TAG, "No weather data passed.");
            temperature = "unknown";
        }

        // Set up Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(getIntent().getStringExtra("city") + ", " + getIntent().getStringExtra("state"));
        }

        // Set up TabLayout and ViewPager2
        TabLayout tabLayout = findViewById(R.id.tabLayout);
        ViewPager2 viewPager = findViewById(R.id.viewPager);
        viewPager.setAdapter(new DetailedWeatherPagerAdapter(getSupportFragmentManager(), getLifecycle(), city, state, weatherData));


        // Attach the TabLayout to the ViewPager2
        new TabLayoutMediator(tabLayout, viewPager, (tab, position) -> {
            switch (position) {
                case 0:
                    tab.setIcon(R.drawable.today);
                    tab.setText("TODAY");
                    break;
                case 1:
                    tab.setIcon(R.drawable.weekly_tab);
                    tab.setText("WEEKLY");
                    break;
                case 2:
                    tab.setIcon(R.drawable.weather_data_tab);
                    tab.setText("WEATHER DATA");
                    break;
            }
            // Default icon tint
            if (tab.getIcon() != null) {
                tab.getIcon().setTint(getResources().getColor(android.R.color.darker_gray));
            }
        }).attach();

        // Ensure only the first tab is selected initially
        TabLayout.Tab firstTab = tabLayout.getTabAt(0);
        if (firstTab != null && firstTab.getIcon() != null) {
            firstTab.getIcon().setTint(getResources().getColor(android.R.color.white));
        }

        // Set a listener to handle tab selection and update icon colors
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if (tab.getIcon() != null) {
                    tab.getIcon().setTint(getResources().getColor(android.R.color.white));
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                if (tab.getIcon() != null) {
                    tab.getIcon().setTint(getResources().getColor(android.R.color.darker_gray));
                }
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu with the Tweet button
        getMenuInflater().inflate(R.menu.menu_detailed_weather, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_tweet) {
            // Handle the tweet button click
            openTweetIntent();
            return true;
        } else if (id == android.R.id.home) {
            // Handle the back button click in the toolbar
            finish(); // Closes the current activity and returns to the previous one
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void openTweetIntent() {
        Log.d(TAG, "Tweeting: City: " + city + ", State: " + state + ", Temperature: " + temperature);

        // Compose the tweet text
        String tweetText = "Check out " + city + ", " + state + ", USA's weather! It is " + temperature + " #CSCI571WeatherSearch";

        // URL encode the tweet text
        String encodedTweet = Uri.encode(tweetText);

        // Create the Twitter intent URL
        String twitterUrl = "https://twitter.com/intent/tweet?text=" + encodedTweet;

        // Launch the browser with the Twitter intent
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(twitterUrl));
        startActivity(browserIntent);
    }
}

