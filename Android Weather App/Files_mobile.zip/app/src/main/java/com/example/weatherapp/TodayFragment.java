package com.example.weatherapp;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import androidx.gridlayout.widget.GridLayout;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

public class TodayFragment extends Fragment {

    private static final String TAG = "TodayFragment";
    private String city;
    private String state;
    private String weatherData;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_today, container, false);

        // Retrieve city, state, and weather data from arguments passed by the parent activity
        Bundle arguments = getArguments();
        if (arguments != null) {
            city = arguments.getString("city");
            state = arguments.getString("state");
            weatherData = arguments.getString("weatherData");

            Log.d(TAG, "Received arguments in TodayFragment: City: " + city + ", State: " + state + ", WeatherData: " + weatherData);

            if (weatherData != null) {
                try {
                    JSONObject response = new JSONObject(weatherData);
                    populateWeatherCards(view, response);
                } catch (Exception e) {
                    Log.e(TAG, "Error parsing passed weather data: " + e.getMessage());
                }
            } else {
                Log.e(TAG, "No weather data passed to TodayFragment. Cannot display data.");

            }
        } else {
            Log.e(TAG, "Arguments are null. Cannot display weather data.");

        }


        return view;
    }

    private void populateWeatherCards(View view, JSONObject response) {
        try {
            JSONObject currentWeather = response.getJSONObject("data").getJSONArray("timelines")
                    .getJSONObject(0).getJSONArray("intervals").getJSONObject(0).getJSONObject("values");

            // Extract required data
            String[] labels = {
                    "Wind Speed", "Pressure", "Precipitation", "Temperature",
                    "Status", "Humidity", "Visibility", "Cloud Cover", "UV Index"
            };

            String[] values = {
                    currentWeather.getDouble("windSpeed") + " mph",
                    currentWeather.getDouble("pressureSeaLevel") + " inHg",
                    currentWeather.getDouble("precipitationProbability") + "%",
                    currentWeather.getDouble("temperature") + "°F",
                    getWeatherDescription(currentWeather.getInt("weatherCode")),
                    currentWeather.getDouble("humidity") + "%",
                    currentWeather.getDouble("visibility") + " mi",
                    currentWeather.getDouble("cloudCover") + "%",
                    String.valueOf(currentWeather.getDouble("uvIndex"))
            };

            int[] icons = {
                    R.drawable.wind_speed, R.drawable.pressure,
                    R.drawable.rain_card, R.drawable.ic_thermometer,
                    getIconResource(currentWeather.getInt("weatherCode")), R.drawable.humidity,
                    R.drawable.visibility, R.drawable.cloud_cover,
                    R.drawable.uv
            };

            GridLayout gridLayout = view.findViewById(R.id.gridLayout);

            for (int i = 0; i <  labels.length; i++) {
                View cardView = LayoutInflater.from(requireContext()).inflate(R.layout.card_template, gridLayout, false);
                ImageView iconView = cardView.findViewById(R.id.card_icon);
                TextView valueView = cardView.findViewById(R.id.card_value);
                TextView labelView = cardView.findViewById(R.id.card_label);

                iconView.setImageResource(icons[i]);
                // Apply black tint to all icons except the dynamic status icon
                if (i == 4) {
                    iconView.clearColorFilter();
                } else {
                    iconView.setColorFilter(getResources().getColor(android.R.color.black));
                }

                valueView.setText(values[i]);
                labelView.setText(labels[i]);

                gridLayout.addView(cardView);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error parsing weather data: " + e.getMessage());
        }
    }

    private String getWeatherDescription(int weatherCode) {
        switch (weatherCode) {
            case 1000: return "Clear";
            case 1001: return "Cloudy";
            case 1100: return "Mostly Clear";
            case 1101: return "Partly Cloudy";
            case 1102: return "Mostly Cloudy";
            case 2000: return "Fog";
            case 2100: return "Light Fog";
            case 3000: return "Light Wind";
            case 3001: return "Windy";
            case 3002: return "Strong Wind";
            case 4000: return "Drizzle";
            case 4200: return "Light Rain";
            case 4001: return "Rain";
            case 4201: return "Heavy Rain";
            case 5000: return "Snow";
            case 5100: return "Light Snow";
            case 5001: return "Flurries";
            case 5101: return "Heavy Snow";
            case 6000: return "Freezing Drizzle";
            case 6001: return "Freezing Rain";
            case 6200: return "Light Freezing Rain";
            case 6201: return "Heavy Freezing Rain";
            case 7000: return "Ice Pellets";
            case 7101: return "Heavy Ice Pellets";
            case 7102: return "Light Ice Pellets";
            case 8000: return "Thunderstorm";
            default: return "Unknown";
        }
    }
    private int getIconResource(int weatherCode) {
        switch (weatherCode) {
            case 1000: return R.drawable.clear_day;
            case 1001: return R.drawable.cloudy;
            case 1100: return R.drawable.mostly_clear_day;
            case 1101: return R.drawable.partly_cloudy_day;
            case 1102: return R.drawable.mostly_cloudy;
            case 2000: return R.drawable.fog;
            case 2100: return R.drawable.fog_light;
            case 3000: return R.drawable.wind_light;
            case 3001: return R.drawable.wind;
            case 3002: return R.drawable.wind_strong;
            case 4000: return R.drawable.drizzle;
            case 4200: return R.drawable.rain_light;
            case 4001: return R.drawable.rain;
            case 4201: return R.drawable.rain_heavy;
            case 5000: return R.drawable.snow;
            case 5100: return R.drawable.snow_light;
            case 5001: return R.drawable.flurries;
            case 5101: return R.drawable.snow_heavy;
            case 6000: return R.drawable.freezing_drizzle;
            case 6001: return R.drawable.freezing_rain;
            case 6200: return R.drawable.freezing_rain_light;
            case 6201: return R.drawable.freezing_rain_heavy;
            case 7000: return R.drawable.ice_pellets;
            case 7101: return R.drawable.ice_pellets_heavy;
            case 7102: return R.drawable.ice_pellets_light;
            case 8000: return R.drawable.tstorm;
            default: return R.drawable.clear_day;
        }
    }

}
