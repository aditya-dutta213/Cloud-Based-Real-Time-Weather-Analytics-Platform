package com.example.weatherapp;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.highsoft.highcharts.common.HIColor;
import com.highsoft.highcharts.common.HIGradient;
import com.highsoft.highcharts.common.HIStop;
import com.highsoft.highcharts.common.hichartsclasses.HIMarker;
import com.highsoft.highcharts.core.HIChartView;
import com.highsoft.highcharts.common.hichartsclasses.HIOptions;
import com.highsoft.highcharts.common.hichartsclasses.HIChart;
import com.highsoft.highcharts.common.hichartsclasses.HIArearange;
import com.highsoft.highcharts.common.hichartsclasses.HIXAxis;
import com.highsoft.highcharts.common.hichartsclasses.HIYAxis;
import com.highsoft.highcharts.common.hichartsclasses.HILegend;
import com.highsoft.highcharts.common.hichartsclasses.HITitle;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Arrays;
import java.text.SimpleDateFormat;
import java.util.Locale;


public class WeeklyFragment extends Fragment {

    private static final String TAG = "WeeklyFragment";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_weekly, container, false);

        HIChartView chartView = view.findViewById(R.id.weekly_chart_view);

        try {
            // Get weather data from arguments
            Bundle args = getArguments();
            String weatherData = args != null ? args.getString("weatherData") : null;

            if (weatherData == null) {
                Log.e(TAG, "No weather data passed to WeeklyFragment.");
                return view;
            }

            // Parse weather data
            ArrayList<Number[]> temperatureRanges = new ArrayList<>();
            ArrayList<String> daysOfWeek = new ArrayList<>();
            parseWeatherData(weatherData, temperatureRanges, daysOfWeek);

            // Set up chart options
            HIOptions options = new HIOptions();

            // Chart configuration
            HIChart chart = new HIChart();
            chart.setType("arearange");
            options.setChart(chart);

            // Chart Title
            HITitle title = new HITitle();
            title.setText("Weekly Temperature Range");
            options.setTitle(title);

            // X-axis configuration
            HIXAxis xAxis = new HIXAxis();
            xAxis.setCategories(daysOfWeek);
            xAxis.setTitle(new HITitle());
            xAxis.getTitle().setText("Day of the Week");

            options.setXAxis(new ArrayList<>(Arrays.asList(xAxis)));

            // Y-axis configuration
            HIYAxis yAxis = new HIYAxis();
            yAxis.setTitle(new HITitle());
            yAxis.getTitle().setText("Temperature (°F)");
            options.setYAxis(new ArrayList<>(List.of(yAxis)));

            // Series data
            HIArearange series = new HIArearange();
            series.setName("Temperature Range");
            series.setData(temperatureRanges);

// Define the gradient
            HIGradient gradient = new HIGradient(0, 0f, 0, 1f);
            LinkedList<HIStop> stops = new LinkedList<>();
            stops.add(new HIStop(0, HIColor.initWithRGB(240, 177, 126)));
            stops.add(new HIStop(1, HIColor.initWithRGB(154, 180, 215)));

// Apply the gradient to the series
            series.setColor(HIColor.initWithLinearGradient(gradient, stops));
            series.setFillOpacity(0.5);

// Configure Markers
            // Define the gradient for markers
            HIGradient markerGradient = new HIGradient(0, 0f, 0, 1f);
            LinkedList<HIStop> markerStops = new LinkedList<>();
            markerStops.add(new HIStop(0, HIColor.initWithRGB(240, 177, 126)));
            markerStops.add(new HIStop(1, HIColor.initWithRGB(154, 180, 215)));

// Configure Markers
            HIMarker marker = new HIMarker();
            marker.setEnabled(true);
            marker.setRadius(6);
            marker.setLineWidth(2);
            marker.setLineColor(HIColor.initWithName("white"));
            marker.setFillColor(HIColor.initWithLinearGradient(markerGradient, markerStops));

// Apply gradient marker to the series
            series.setMarker(marker);
// Add series to chart
            options.setSeries(new ArrayList<>(List.of(series)));


            // Legend configuration
            HILegend legend = new HILegend();
            legend.setEnabled(false);
            legend.setLayout("horizontal");
            legend.setAlign("center");
            options.setLegend(legend);

            // Apply options to chart
            chartView.setOptions(options);
            Log.d(TAG, "Chart successfully created with real data.");
        } catch (Exception e) {
            Log.e(TAG, "Error initializing chart with real data: " + e.getMessage(), e);
        }

        return view;
    }

    private void parseWeatherData(String weatherData, ArrayList<Number[]> temperatureRanges, ArrayList<String> daysOfWeek) {
        try {
            JSONObject response = new JSONObject(weatherData);
            JSONArray dailyIntervals = response.getJSONObject("data").getJSONArray("timelines")
                    .getJSONObject(0).getJSONArray("intervals");

            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.getDefault());
            SimpleDateFormat outputFormat = new SimpleDateFormat("dd MMM", Locale.getDefault());
            for (int i = 0; i < dailyIntervals.length(); i++) {
                JSONObject interval = dailyIntervals.getJSONObject(i);
                JSONObject values = interval.getJSONObject("values");

                // Extract temperatureMin and temperatureMax
                double tempLow = values.optDouble("temperatureMin", Double.NaN);
                double tempHigh = values.optDouble("temperatureMax", Double.NaN);

                // Parse and format the date
                String rawDate = interval.getString("startTime");
                Date date = inputFormat.parse(rawDate);
                String formattedDate = outputFormat.format(date);

                // Add to temperature ranges
                if (!Double.isNaN(tempLow) && !Double.isNaN(tempHigh)) {
                    temperatureRanges.add(new Number[]{tempLow, tempHigh});
                    daysOfWeek.add(formattedDate);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error parsing weather data: " + e.getMessage(), e);
        }
    }

    private String getDayOfWeekFromDate(String date) {
        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            Date parsedDate = format.parse(date);
            SimpleDateFormat dayFormat = new SimpleDateFormat("EEEE", Locale.getDefault());
            return dayFormat.format(parsedDate);
        } catch (Exception e) {
            Log.e(TAG, "Error parsing date: " + e.getMessage(), e);
            return "";
        }
    }
}
