package com.example.weatherapp;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.highsoft.highcharts.common.HIColor;
import com.highsoft.highcharts.common.hichartsclasses.*;
import com.highsoft.highcharts.core.HIChartView;
import com.highsoft.highcharts.core.HIFunction;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

import org.json.JSONObject;

public class WeatherDataFragment extends Fragment {

    private static final String TAG = "WeatherDataFragment";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_weather_data, container, false);

        HIChartView chartView = view.findViewById(R.id.weather_data_chart);

        try {
            // Retrieve weather data from arguments
            Bundle args = getArguments();
            String weatherData = args != null ? args.getString("weatherData") : null;

            if (weatherData == null) {
                Log.e(TAG, "No weather data passed to WeatherDataFragment.");
                return view;
            }

            // Parse the weather data JSON
            JSONObject response = new JSONObject(weatherData);
            JSONObject currentWeather = response.getJSONObject("data")
                    .getJSONArray("timelines")
                    .getJSONObject(0)
                    .getJSONArray("intervals")
                    .getJSONObject(0)
                    .getJSONObject("values");

            double cloudCover = currentWeather.optDouble("cloudCover", 0);
            double precipitation = currentWeather.optDouble("precipitationProbability", 0);
            double humidity = currentWeather.optDouble("humidity", 0);

            // Configure the chart
            HIOptions options = createGaugeChartOptions(cloudCover, precipitation, humidity);

            // Apply options to chart view
            chartView.setOptions(options);

        } catch (Exception e) {
            Log.e(TAG, "Error parsing weather data: " + e.getMessage(), e);
        }

        return view;
    }

    private HIOptions createGaugeChartOptions(double cloudCover, double precipitation, double humidity) {
        HIOptions options = new HIOptions();

        // Chart setup
        HIChart chart = new HIChart();
        chart.setType("solidgauge");

        // Add render event for icons
        HIEvents events = new HIEvents();
        events.setRender(new HIFunction("function renderIcons() {" +
                "   if (!this.series[0].icon) {" +
                "       this.series[0].icon = this.renderer.path(['M', -8, 0, 'L', 8, 0, 'M', 0, -8, 'L', 8, 0, 0, 8])" +
                "           .attr({'stroke': '#303030', 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'stroke-width': 2, 'zIndex': 10})" +
                "           .add(this.series[2].group);" +
                "   }" +
                "   this.series[0].icon.translate(this.chartWidth / 2 - 10, this.plotHeight / 2 - this.series[0].points[0].shapeArgs.innerR - (this.series[0].points[0].shapeArgs.r - this.series[0].points[0].shapeArgs.innerR) / 2);" +
                "   if (!this.series[1].icon) {" +
                "       this.series[1].icon = this.renderer.path(['M', -8, 0, 'L', 8, 0, 'M', 0, -8, 'L', 8, 0, 0, 8, 'M', 8, -8, 'L', 16, 0, 8, 8])" +
                "           .attr({'stroke': '#ffffff', 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'stroke-width': 2, 'zIndex': 10})" +
                "           .add(this.series[2].group);" +
                "   }" +
                "   this.series[1].icon.translate(this.chartWidth / 2 - 10, this.plotHeight / 2 - this.series[1].points[0].shapeArgs.innerR - (this.series[1].points[0].shapeArgs.r - this.series[1].points[0].shapeArgs.innerR) / 2);" +
                "   if (!this.series[2].icon) {" +
                "       this.series[2].icon = this.renderer.path(['M', 0, 8, 'L', 0, -8, 'M', -8, 0, 'L', 0, -8, 8, 0])" +
                "           .attr({'stroke': '#303030', 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'stroke-width': 2, 'zIndex': 10})" +
                "           .add(this.series[2].group);" +
                "   }" +
                "   this.series[2].icon.translate(this.chartWidth / 2 - 10, this.plotHeight / 2 - this.series[2].points[0].shapeArgs.innerR - (this.series[2].points[0].shapeArgs.r - this.series[2].points[0].shapeArgs.innerR) / 2);" +
                "}"));
        chart.setEvents(events);
        options.setChart(chart);

        // Chart title
        HITitle title = new HITitle();
        title.setText("Stats Summary");
        title.setStyle(new HICSSObject());
        title.getStyle().setFontSize("20px");
        options.setTitle(title);

        // Pane setup
        HIPane pane = new HIPane();
        pane.setStartAngle(0);
        pane.setEndAngle(360);

        HIBackground outerBackground = new HIBackground();
        outerBackground.setOuterRadius("112%");
        outerBackground.setInnerRadius("88%");
        outerBackground.setBackgroundColor(HIColor.initWithRGBA(130, 237, 105, 0.35));
        outerBackground.setBorderWidth(0);

        HIBackground middleBackground = new HIBackground();
        middleBackground.setOuterRadius("87%");
        middleBackground.setInnerRadius("63%");
        middleBackground.setBackgroundColor(HIColor.initWithRGBA(105, 164, 230, 0.35));
        middleBackground.setBorderWidth(0);

        HIBackground innerBackground = new HIBackground();
        innerBackground.setOuterRadius("62%");
        innerBackground.setInnerRadius("38%");
        innerBackground.setBackgroundColor(HIColor.initWithRGBA(255, 128, 93, 0.35));
        innerBackground.setBorderWidth(0);

        pane.setBackground(new ArrayList<>(Arrays.asList(outerBackground, middleBackground, innerBackground)));
        options.setPane(new ArrayList<>(Collections.singletonList(pane)));

        // Y-axis setup
        HIYAxis yAxis = new HIYAxis();
        yAxis.setMin(0);
        yAxis.setMax(100);
        yAxis.setLineWidth(0);
        yAxis.setTickPositions(new ArrayList<>());
        options.setYAxis(new ArrayList<>(Collections.singletonList(yAxis)));

        // Plot options
        HIPlotOptions plotOptions = new HIPlotOptions();
        HISolidgauge solidgaugeOptions = new HISolidgauge();
        solidgaugeOptions.setLinecap("round");
        solidgaugeOptions.setStickyTracking(false);
        solidgaugeOptions.setRounded(true);
        plotOptions.setSolidgauge(solidgaugeOptions);
        options.setPlotOptions(plotOptions);

        // Series data
        HISolidgauge humidityGauge = createSolidGaugeSeries("Humidity", humidity,  130, 237, 105, "112%", "88%");
        HISolidgauge precipitationGauge = createSolidGaugeSeries("Precipitation", precipitation, 105, 164, 230, "87%", "63%");
        HISolidgauge cloudCoverGauge = createSolidGaugeSeries("Cloud Cover", cloudCover, 255, 128, 93, "62%", "38%");

        options.setSeries(new ArrayList<>(Arrays.asList(humidityGauge, precipitationGauge, cloudCoverGauge)));

        return options;
    }

    private HISolidgauge createSolidGaugeSeries(String name, double value, int r, int g, int b, String outerRadius, String innerRadius) {
        HISolidgauge series = new HISolidgauge();
        series.setName(name);

        HIData data = new HIData();
        data.setY(value);
        data.setColor(HIColor.initWithRGB(r, g, b));
        data.setRadius(outerRadius);
        data.setInnerRadius(innerRadius);

        series.setData(new ArrayList<>(Collections.singletonList(data)));

        // Add data labels
        HIDataLabels dataLabels = new HIDataLabels();
        dataLabels.setEnabled(false);
        series.setDataLabels(new ArrayList<>(Collections.singletonList(dataLabels)));

        return series;
    }
}
