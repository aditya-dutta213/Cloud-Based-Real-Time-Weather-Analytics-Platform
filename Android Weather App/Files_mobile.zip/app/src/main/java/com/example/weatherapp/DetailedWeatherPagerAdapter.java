package com.example.weatherapp;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Lifecycle;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import android.os.Bundle;

// Import your fragments
import com.example.weatherapp.TodayFragment;

public class DetailedWeatherPagerAdapter extends FragmentStateAdapter {

    private final String city;
    private final String state;
    private final String weatherData;


    public DetailedWeatherPagerAdapter(@NonNull FragmentManager fragmentManager, @NonNull Lifecycle lifecycle,String city, String state, String weatherData) {
        super(fragmentManager, lifecycle);
        this.city = city;
        this.state = state;
        this.weatherData = weatherData;
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position) {
            case 0: {
                // Pass city and state to TodayFragment
                TodayFragment todayFragment = new TodayFragment();
                Bundle args = new Bundle();
                args.putString("city", city);
                args.putString("state", state);
                args.putString("weatherData", weatherData);
                todayFragment.setArguments(args);
                return todayFragment;
            }
            case 1: {
                // Pass weather data to WeeklyFragment
                WeeklyFragment weeklyFragment = new WeeklyFragment();
                Bundle args = new Bundle();
                args.putString("weatherData", weatherData);
                weeklyFragment.setArguments(args);
                return weeklyFragment;
            }
            case 2: {
                WeatherDataFragment weatherDataFragment = new WeatherDataFragment();
                Bundle args = new Bundle();
                args.putString("weatherData", weatherData);
                weatherDataFragment.setArguments(args);
                return weatherDataFragment;
            }

            default:
                throw new IllegalArgumentException("Invalid position: " + position);
        }
    }

    @Override
    public int getItemCount() {
        return 3;
    }
}
