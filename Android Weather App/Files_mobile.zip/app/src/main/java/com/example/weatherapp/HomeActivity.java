package com.example.weatherapp;

import android.os.Bundle;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import android.view.View;
import android.widget.TextView;
import android.widget.ImageView;

import android.view.Gravity;
import android.widget.LinearLayout;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.graphics.Color;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import androidx.appcompat.widget.SearchView;

import androidx.appcompat.content.res.AppCompatResources;
import android.graphics.drawable.Drawable;

import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.AdapterView;
import android.content.Intent;
import androidx.cardview.widget.CardView;

interface FavoritesCountCallback {
    void onSuccess(int count);
    void onFailure(Exception e);
}

public class HomeActivity extends AppCompatActivity {
    private static final String TAG = "IPinfo";
    private static final String IPINFO_URL = "https://ipinfo.io?token=77f687734804f6";
    private static final String BACKEND_URL = "https://backend-dot-weather-search-project.wl.r.appspot.com/get_weather";
    private String city = "N/A";
    private String state = "N/A";
    private String loc = "0,0";
    private JSONObject weatherData;

    private SearchView searchView;
    private boolean isSuggestionSelected = false;
    private int currentDotIndex = 0;
    private int selectedDotIndex = 0;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_home);

        // Link the Toolbar
        androidx.appcompat.widget.Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Handle edge-to-edge padding
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main_content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        // Find Card 1
        CardView cardCurrentWeather = findViewById(R.id.card_current_weather);

        // Set Click Listener
        cardCurrentWeather.setOnClickListener(view -> {
            if (weatherData != null) {
                Intent intent = new Intent(HomeActivity.this, DetailedWeatherActivity.class);

                // Pass city, state, and weather data to DetailedWeatherActivity
                intent.putExtra("city", city);
                intent.putExtra("state", state);
                intent.putExtra("weatherData", weatherData.toString());
                startActivity(intent);
            } else {
                Toast.makeText(this, "Weather data is not available yet.", Toast.LENGTH_SHORT).show();
            }
        });

        // Fetch location using IPinfo
        fetchLocation();
        updateTabsAndDots();
    }

    private void fetchLocation() {
        showProgressBar("Fetching Location...");

        RequestQueue queue = Volley.newRequestQueue(this);

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, IPINFO_URL, null,
                response -> {
                    city = response.optString("city", "N/A");
                    state = response.optString("region", "N/A");
                    loc = response.optString("loc", "0,0");
                    Log.d(TAG, "City: " + city + ", State: " + state + ", Location: " + loc);

                    fetchWeatherData(city, state);

                    updateLocationText(city, state);
                },
                error -> {
                    Log.e(TAG, "Error fetching location: " + error.getMessage());
                    Toast.makeText(this, "Failed to fetch location.", Toast.LENGTH_SHORT).show();
                    hideProgressBar();
                });

        queue.add(jsonObjectRequest);
    }


    private void fetchWeatherData(String city, String state) {
        if ("N/A".equals(city) || "N/A".equals(state)) {
            Log.e(TAG, "Invalid location. Skipping weather API call.");
            return;
        }

        showProgressBar("Fetching Weather...");

        String url = BACKEND_URL + "?city=" + city + "&state=" + state;
        RequestQueue queue = Volley.newRequestQueue(this);

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    Log.d(TAG, "Weather Data: " + response.toString());
                    weatherData = response;

                    parseAndDisplayCurrentWeather(response);
                    parseAndDisplayWeatherMetrics(response);
                    parseAndDisplayForecast(response);

                    hideProgressBar();
                },
                error -> {
                    Log.e(TAG, "Error fetching weather data: " + error.getMessage());
                    Toast.makeText(this, "Failed to fetch weather data.", Toast.LENGTH_SHORT).show();
                    hideProgressBar();
                });

        queue.add(jsonObjectRequest);
    }


    private void parseAndDisplayCurrentWeather(JSONObject response) {
        try {
            JSONObject currentWeather = response.getJSONObject("data").getJSONArray("timelines")
                    .getJSONObject(0).getJSONArray("intervals").getJSONObject(0).getJSONObject("values");

            // Extract required data
            int temperature = Math.round((float) currentWeather.getDouble("temperature"));
            int weatherCode = currentWeather.getInt("weatherCode");
            String summary = getWeatherDescription(weatherCode);

            // Update Card 1 UI elements
            TextView cityTextView = findViewById(R.id.card_current_weather_city);
            TextView tempTextView = findViewById(R.id.card_current_weather_temp);
            TextView summaryTextView = findViewById(R.id.card_current_weather_summary);
            ImageView weatherIcon = findViewById(R.id.card_current_weather_icon);

            cityTextView.setText(city + ", " + state);
            tempTextView.setText(temperature + "°F");
            summaryTextView.setText(summary);
            weatherIcon.setImageResource(getIconResource(weatherCode));
        } catch (Exception e) {
            Log.e(TAG, "Error parsing weather data: " + e.getMessage());
        }
    }

    private String getWeatherDescription(int weatherCode) {
        switch (weatherCode) {
            case 1000: return "Clear";
            case 1001: return "Cloudy";
            case 1100: return "Mostly Clear";
            case 1101: return "Partly Cloudy";
            case 1102: return "Mostly Cloudy";
            case 2000: return "Fog";
            case 2100: return "Light Fog";
            case 3000: return "Light Wind";
            case 3001: return "Windy";
            case 3002: return "Strong Wind";
            case 4000: return "Drizzle";
            case 4200: return "Light Rain";
            case 4001: return "Rain";
            case 4201: return "Heavy Rain";
            case 5000: return "Snow";
            case 5100: return "Light Snow";
            case 5001: return "Flurries";
            case 5101: return "Heavy Snow";
            case 6000: return "Freezing Drizzle";
            case 6001: return "Freezing Rain";
            case 6200: return "Light Freezing Rain";
            case 6201: return "Heavy Freezing Rain";
            case 7000: return "Ice Pellets";
            case 7101: return "Heavy Ice Pellets";
            case 7102: return "Light Ice Pellets";
            case 8000: return "Thunderstorm";
            default: return "Unknown";
        }
    }

    private int getIconResource(int weatherCode) {
        switch (weatherCode) {
            case 1000: return R.drawable.clear_day;
            case 1001: return R.drawable.cloudy;
            case 1100: return R.drawable.mostly_clear_day;
            case 1101: return R.drawable.partly_cloudy_day;
            case 1102: return R.drawable.mostly_cloudy;
            case 2000: return R.drawable.fog;
            case 2100: return R.drawable.fog_light;
            case 3000: return R.drawable.wind_light;
            case 3001: return R.drawable.wind;
            case 3002: return R.drawable.wind_strong;
            case 4000: return R.drawable.drizzle;
            case 4200: return R.drawable.rain_light;
            case 4001: return R.drawable.rain;
            case 4201: return R.drawable.rain_heavy;
            case 5000: return R.drawable.snow;
            case 5100: return R.drawable.snow_light;
            case 5001: return R.drawable.flurries;
            case 5101: return R.drawable.snow_heavy;
            case 6000: return R.drawable.freezing_drizzle;
            case 6001: return R.drawable.freezing_rain;
            case 6200: return R.drawable.freezing_rain_light;
            case 6201: return R.drawable.freezing_rain_heavy;
            case 7000: return R.drawable.ice_pellets;
            case 7101: return R.drawable.ice_pellets_heavy;
            case 7102: return R.drawable.ice_pellets_light;
            case 8000: return R.drawable.tstorm;
            default: return R.drawable.clear_day;
        }
    }
    private void parseAndDisplayWeatherMetrics(JSONObject response) {
        try {
            JSONObject currentWeather = response.getJSONObject("data").getJSONArray("timelines")
                    .getJSONObject(0).getJSONArray("intervals").getJSONObject(0).getJSONObject("values");

            // Extract weather metrics
            double humidityFraction = currentWeather.getDouble("humidity");
            double windSpeed = currentWeather.getDouble("windSpeed");
            double visibility = currentWeather.getDouble("visibility");
            double pressure = currentWeather.getDouble("pressureSeaLevel");

            // Convert humidity to percentage
            int humidityPercentage = (int) Math.round(humidityFraction);

            // Round other values to 2 decimal places
            String windSpeedFormatted = String.format("%.2f mph", windSpeed);
            String visibilityFormatted = String.format("%.2f mi", visibility);
            String pressureFormatted = String.format("%.2f inHg", pressure);

            // Update UI
            TextView humidityValue = findViewById(R.id.value_humidity);
            TextView windSpeedValue = findViewById(R.id.value_wind_speed);
            TextView visibilityValue = findViewById(R.id.value_visibility);
            TextView pressureValue = findViewById(R.id.value_pressure);

            humidityValue.setText(humidityPercentage + "%");
            windSpeedValue.setText(windSpeedFormatted);
            visibilityValue.setText(visibilityFormatted);
            pressureValue.setText(pressureFormatted);

        } catch (Exception e) {
            Log.e(TAG, "Error parsing weather metrics: " + e.getMessage());
        }
    }

    private void parseAndDisplayForecast(JSONObject response) {
        try {
            JSONArray dailyIntervals = response.getJSONObject("data").getJSONArray("timelines")
                    .getJSONObject(0).getJSONArray("intervals");

            LinearLayout forecastTable = findViewById(R.id.forecast_table);
            forecastTable.removeAllViews();

            for (int i = 0; i < Math.min(dailyIntervals.length(), 7); i++) {
                JSONObject interval = dailyIntervals.getJSONObject(i);
                JSONObject values = interval.getJSONObject("values");
                String date = interval.getString("startTime").split("T")[0];
                int weatherCode = values.getInt("weatherCode");
                int tempLow = Math.round((float) values.getDouble("temperatureMin"));
                int tempHigh = Math.round((float) values.getDouble("temperatureMax"));

                addForecastRow(forecastTable, date, weatherCode, tempLow, tempHigh);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error parsing forecast data: " + e.getMessage());
        }
    }
    private void addForecastRow(LinearLayout table, String date, int weatherCode, int tempLow, int tempHigh) {
        // Container for spacing and background
        LinearLayout rowContainer = new LinearLayout(this);
        rowContainer.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        rowContainer.setPadding(0, 8, 0, 8);
        rowContainer.setBackgroundColor(Color.parseColor("#2d2d2d"));

        // Actual row content
        LinearLayout row = new LinearLayout(this);
        LinearLayout.LayoutParams rowLayoutParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        row.setLayoutParams(rowLayoutParams);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(16, 16, 16, 16);
        row.setBackgroundColor(Color.parseColor("#1E1E1E"));
        row.setGravity(Gravity.CENTER_VERTICAL);

        // Date
        TextView dateView = new TextView(this);
        dateView.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 2));
        dateView.setText(date);
        dateView.setTextColor(getResources().getColor(android.R.color.white));
        dateView.setTextSize(14);
        row.addView(dateView);

        // Icon
        ImageView weatherIcon = new ImageView(this);
        weatherIcon.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        weatherIcon.setImageResource(getIconResource(weatherCode));
        row.addView(weatherIcon);

        // Min Temp
        TextView minTempView = new TextView(this);
        minTempView.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        minTempView.setText(tempLow + "°F");
        minTempView.setTextColor(getResources().getColor(android.R.color.white));
        minTempView.setTextSize(14);
        minTempView.setGravity(Gravity.CENTER);
        row.addView(minTempView);

        // Max Temp
        TextView maxTempView = new TextView(this);
        maxTempView.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        maxTempView.setText(tempHigh + "°F");
        maxTempView.setTextColor(getResources().getColor(android.R.color.white));
        maxTempView.setTextSize(14);
        maxTempView.setGravity(Gravity.CENTER);
        row.addView(maxTempView);

        // Add row to the container
        rowContainer.addView(row);

        // Add the container to the table
        table.addView(rowContainer);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu resource
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_search, menu);

        // Get the search item and its action view
        MenuItem searchItem = menu.findItem(R.id.action_search);
        searchView = (SearchView) searchItem.getActionView();

        if (searchView != null) {
            searchView.setQueryHint("Enter city name...");

            searchView.setBackgroundColor(Color.BLACK);

            // Set the navigation (back arrow) color
            androidx.appcompat.widget.Toolbar toolbar = findViewById(R.id.toolbar);
            if (toolbar != null) {
                Drawable navigationIcon = toolbar.getNavigationIcon();
                if (navigationIcon != null) {
                    navigationIcon.setTint(Color.WHITE);
                    toolbar.setNavigationIcon(navigationIcon);
                }
            }

            // Access the AutoCompleteTextView inside the SearchView
            AutoCompleteTextView searchAutoComplete = searchView.findViewById(androidx.appcompat.R.id.search_src_text);
            if (searchAutoComplete != null) {
                searchAutoComplete.setThreshold(1);

                // Set the dropdown background and text colors
                searchAutoComplete.setBackgroundColor(Color.BLACK);
                searchAutoComplete.setTextColor(Color.WHITE);
                searchAutoComplete.setHintTextColor(Color.GRAY);

                // Set up an ArrayAdapter for suggestions
                ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                        R.layout.dropdown_item, new ArrayList<>());
                searchAutoComplete.setAdapter(adapter);

                // Handle suggestion click events
                searchAutoComplete.setOnItemClickListener((parent, view, position, id) -> {
                    String selectedCityState = (String) parent.getItemAtPosition(position);
                    isSuggestionSelected = true; // Set the flag
                    searchAutoComplete.setText(selectedCityState);

                    // Dismiss dropdown after selection
                    searchAutoComplete.dismissDropDown();
                    searchAutoComplete.clearFocus();
                    Log.d("Autocomplete", "Suggestion selected: " + selectedCityState);
                });

                // Listen for text changes to fetch suggestions dynamically
                searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                    @Override
                    public boolean onQueryTextSubmit(String query) {
                        String[] parts = query.split(", ");
                        String city = parts[0];
                        String state = parts.length > 1 ? parts[1] : "";
                        if (city.isEmpty()) {
                            Toast.makeText(HomeActivity.this, "Please enter a valid city name", Toast.LENGTH_SHORT).show();
                            return false; // Do not proceed if city is empty
                        }

                        // Log the selected city and state
                        Log.d("SearchQuery", "City: " + city + ", State: " + state);

                        // Create an intent to launch SearchResultsActivity
                        Intent intent = new Intent(HomeActivity.this, SearchResultsActivity.class);
                        intent.putExtra("city", city);
                        intent.putExtra("state", state);

                        // Start the new activity
                        startActivity(intent);
                        searchView.clearFocus();
                        return true;
                    }

                    @Override
                    public boolean onQueryTextChange(String newText) {
                        if (isSuggestionSelected) {
                            isSuggestionSelected = false;
                            return false;
                        }

                        AutoCompleteTextView searchAutoComplete = searchView.findViewById(androidx.appcompat.R.id.search_src_text);

                        if (newText.trim().isEmpty()) {
                            // If query is empty, clear the adapter and dismiss the dropdown
                            adapter.clear();
                            adapter.notifyDataSetChanged();
                            if (searchAutoComplete != null) {
                                searchAutoComplete.dismissDropDown();
                            }
                        } else {
                            // Fetch new suggestions for the current query
                            fetchCitySuggestions(newText, adapter);

                            if (searchAutoComplete != null) {
                                searchAutoComplete.requestFocus();
                                searchAutoComplete.postDelayed(() -> {
                                    searchAutoComplete.dismissDropDown();
                                    searchAutoComplete.showDropDown();
                                }, 50);
                            }
                        }

                        return false;
                    }


                });
            } else {
                Log.e(TAG, "AutoCompleteTextView is null!");
            }
        } else {
            Log.e(TAG, "SearchView is null!");
        }

        return true;
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle other menu item clicks if needed
        return super.onOptionsItemSelected(item);
    }
    private void fetchCitySuggestions(String query, ArrayAdapter<String> adapter) {
        if (query == null || query.trim().isEmpty()) return;

        String url = "https://backend-dot-weather-search-project.wl.r.appspot.com/proxy?input=" + query;

        // Make a GET request to fetch suggestions
        RequestQueue queue = Volley.newRequestQueue(this);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    try {
                        Log.d("Autocomplete", "Query: " + query);
                        Log.d("Autocomplete", "Response: " + response.toString());
                        JSONArray predictions = response.getJSONArray("predictions");
                        List<String> suggestions = new ArrayList<>();

                        // Extract city and state from the API response
                        for (int i = 0; i < predictions.length(); i++) {
                            JSONObject prediction = predictions.getJSONObject(i);
                            String city = prediction.getJSONArray("terms").getJSONObject(0).getString("value");
                            String state = prediction.getJSONArray("terms").getJSONObject(1).getString("value");
                            suggestions.add(city + ", " + state);
                        }

                        // Handle empty suggestions
                        if (suggestions.isEmpty()) {
                            Log.d("Autocomplete", "No predictions found for query: " + query);
                            suggestions.add("No suggestions found");
                        }

                        // Update the adapter with the fetched suggestions
                        adapter.clear();
                        adapter.addAll(suggestions);
                        adapter.notifyDataSetChanged();
                        Log.d("Autocomplete", "Updated Suggestions: " + suggestions.toString());

                        // Force dropdown to show updated suggestions
                        if (searchView != null) {
                            AutoCompleteTextView searchAutoComplete = searchView.findViewById(androidx.appcompat.R.id.search_src_text);
                            if (searchAutoComplete != null) {
                                searchAutoComplete.clearFocus();
                                searchAutoComplete.requestFocus();
                                searchAutoComplete.post(() -> {
                                    searchAutoComplete.dismissDropDown();
                                    searchAutoComplete.showDropDown();
                                    Log.d("Autocomplete", "Dropdown forced refresh for query: " + query);
                                });
                            }
                        }
                    } catch (Exception e) {
                        Log.e("Autocomplete", "Error parsing suggestions: " + e.getMessage());
                    }
                },
                error -> Log.e("Autocomplete", "Error fetching suggestions: " + error.getMessage())
        );

        // Add the request to the Volley queue
        queue.add(jsonObjectRequest);
    }


    private void updateSuggestions(List<String> suggestions) {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, suggestions);

        if (searchView != null) { // Use the global searchView reference
            AutoCompleteTextView searchAutoComplete = searchView.findViewById(androidx.appcompat.R.id.search_src_text);

            if (searchAutoComplete != null) {
                searchAutoComplete.setAdapter(adapter);
                searchAutoComplete.setOnItemClickListener((parent, view, position, id) -> {
                    String selectedCityState = (String) parent.getItemAtPosition(position);
                    searchAutoComplete.setText(selectedCityState);
                    Toast.makeText(HomeActivity.this, "Selected: " + selectedCityState, Toast.LENGTH_SHORT).show();
                });
            } else {
                Log.e("SearchView", "Search AutoComplete is null!");
            }
        } else {
            Log.e("SearchView", "SearchView is null!");
        }
    }

    private void setupDotIndicators(int count) {
        Log.d("DotsSetup", "Setting up " + count + " dots");
        LinearLayout dotsLayout = findViewById(R.id.dots_layout);
        dotsLayout.removeAllViews();

        for (int i = 0; i < count; i++) {
            ImageView dot = new ImageView(this);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            params.setMargins(8, 0, 8, 0);
            dot.setLayoutParams(params);
            dot.setImageResource(R.drawable.dot_inactive);

            // Add a click listener to each dot
            final int dotIndex = i;
            dot.setOnClickListener(view -> {
                // Update the currentDotIndex and highlight the clicked dot
                currentDotIndex = dotIndex;
                highlightActiveDot(dotIndex);

                // Fetch and update weather data for the selected favorite city
                fetchWeatherForFavorite(dotIndex);
            });

            dotsLayout.addView(dot);
        }

        // Highlight the active dot (initially the first one)
        highlightActiveDot(0);
    }

    private void fetchWeatherForFavorite(int index) {
        if (index == 0) {
            // Index 0 is for the current location
            fetchLocation();
        } else {
            // Fetch data for the favorite city based on index
            String url = "https://backend-dot-weather-search-project.wl.r.appspot.com/favorites";
            RequestQueue queue = Volley.newRequestQueue(this);

            JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null,
                    response -> {
                        try {
                            if (index - 1 < response.length()) {
                                JSONObject favorite = response.getJSONObject(index - 1);
                                city = favorite.getString("city");
                                state = favorite.getString("state");


                                // Fetch weather data for the selected favorite city
                                fetchWeatherData(city, state);

                                // Update the location text in Card 1
                                updateLocationText(city, state);
                            } else {
                                Log.e("fetchWeatherForFavorite", "Invalid index: " + index);
                            }
                        } catch (JSONException e) {
                            Log.e("fetchWeatherForFavorite", "Error parsing favorites: " + e.getMessage());
                        }
                    },
                    error -> Log.e("fetchWeatherForFavorite", "Error fetching favorites: " + error.getMessage()));

            queue.add(jsonArrayRequest);
        }
    }
    private void updateLocationText(String city, String state) {
        TextView cityTextView = findViewById(R.id.card_current_weather_city);
        cityTextView.setText(city + ", " + state);
    }

    private void highlightActiveDot(int position) {
        LinearLayout dotsLayout = findViewById(R.id.dots_layout);
        for (int i = 0; i < dotsLayout.getChildCount(); i++) {
            ImageView dot = (ImageView) dotsLayout.getChildAt(i);
            if (i == position) {
                dot.setImageResource(R.drawable.dot_active);
            } else {
                dot.setImageResource(R.drawable.dot_inactive);
            }
        }
    }
    private void updateTabsAndDots() {
        getFavoritesCountAsync(new FavoritesCountCallback() {
            @Override
            public void onSuccess(int count) {
                Log.d("TabsAndDots", "Fetched favorite count: " + count);

                // Preserve the current dot index
                int previousDotIndex = currentDotIndex;

                setupDotIndicators(count + 1);
                // Restore the previously selected dot
                currentDotIndex = previousDotIndex;
                highlightActiveDot(currentDotIndex);
            }

            @Override
            public void onFailure(Exception e) {
                Log.e("TabsAndDots", "Failed to update tabs and dots: " + e.getMessage());
                Toast.makeText(HomeActivity.this, "Failed to update tabs and dots.", Toast.LENGTH_SHORT).show();
            }
        });
    }
    @Override
    protected void onResume() {
        super.onResume();
        Log.d("HomeActivity", "onResume called, restoring selected dot and updating data.");

        // Refresh the tabs and dots to reflect updated favorites
        updateTabsAndDots();

        // After updating tabs, reset to the first dot indicator (for current location)
        currentDotIndex = 0;

        // Highlight the currently selected dot
        highlightActiveDot(currentDotIndex);

        // Fetch weather data for the currently selected dot
        fetchWeatherForFavorite(currentDotIndex);
    }


    private void getFavoritesCountAsync(FavoritesCountCallback callback) {
        String url = "https://backend-dot-weather-search-project.wl.r.appspot.com/favorites";

        RequestQueue queue = Volley.newRequestQueue(this);

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null,
                response -> {
                    try {
                        // Log the raw response for debugging
                        Log.d("getFavoritesCount", "Raw response: " + response.toString());

                        // Count the number of items in the array
                        callback.onSuccess(response.length());
                    } catch (Exception e) {
                        Log.e("getFavoritesCount", "Error parsing favorites: " + e.getMessage());
                        callback.onFailure(e);
                    }
                },
                error -> {
                    // Log error details for debugging
                    Log.e("getFavoritesCount", "Error fetching favorites: " + error.getMessage());
                    callback.onFailure(error);
                });

        queue.add(jsonArrayRequest);
    }
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("currentDotIndex", currentDotIndex);
    }
    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        if (savedInstanceState != null) {
            currentDotIndex = savedInstanceState.getInt("currentDotIndex", 0);
            highlightActiveDot(currentDotIndex);
            fetchWeatherForFavorite(currentDotIndex);
        }
    }
    // Show ProgressBar and hide main content
    private void showProgressBar(String message) {
        LinearLayout progressBarContainer = findViewById(R.id.progress_bar_container);
        TextView progressBarText = findViewById(R.id.progress_bar_text);
        LinearLayout mainContent = findViewById(R.id.main_content);

        progressBarText.setText(message);
        progressBarContainer.setVisibility(View.VISIBLE);
        mainContent.setVisibility(View.GONE);
    }

    // Hide ProgressBar and show main content
    private void hideProgressBar() {
        LinearLayout progressBarContainer = findViewById(R.id.progress_bar_container);
        LinearLayout mainContent = findViewById(R.id.main_content);

        progressBarContainer.setVisibility(View.GONE);
        mainContent.setVisibility(View.VISIBLE);
    }




}

