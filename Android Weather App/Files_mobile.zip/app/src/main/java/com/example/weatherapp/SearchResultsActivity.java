package com.example.weatherapp;

import android.os.Bundle;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import android.view.View;
import android.widget.TextView;
import android.widget.ImageView;

import android.view.Gravity;
import android.widget.LinearLayout;
import org.json.JSONArray;
import org.json.JSONObject;

import android.graphics.Color;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import androidx.appcompat.widget.SearchView;

import androidx.appcompat.content.res.AppCompatResources;
import android.graphics.drawable.Drawable;

import android.widget.Toast;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.AdapterView;
import android.content.Intent;
import androidx.cardview.widget.CardView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;


public class SearchResultsActivity extends AppCompatActivity {
    private static final String TAG = "SearchResults";
    private static final String BACKEND_URL = "https://backend-dot-weather-search-project.wl.r.appspot.com/get_weather";
    private static final String FAVORITES_URL = "https://backend-dot-weather-search-project.wl.r.appspot.com";
    private String city;
    private String state;
    private JSONObject weatherData;
    private FloatingActionButton fabFavorite;
    private boolean isFavorite = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_results);

        // Get Intent Data from HomeActivity
        city = getIntent().getStringExtra("city");
        state = getIntent().getStringExtra("state");

        // Update toolbar title with city and state
        androidx.appcompat.widget.Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(city + ", " + state);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        // Initialize FAB
        fabFavorite = findViewById(R.id.fab_favorite);
        checkIfFavorite();
        updateFabIcon();

        fabFavorite.setOnClickListener(view -> {
            isFavorite = !isFavorite;
            updateFabIcon();
            if (isFavorite) {
                addToFavorites();
                Toast.makeText(this, city + " was added to favorites", Toast.LENGTH_SHORT).show();
            } else {
                removeFromFavorites();
                Toast.makeText(this, city + " was removed from favorites", Toast.LENGTH_SHORT).show();
            }
        });

        // Find Card 1
        CardView cardCurrentWeather = findViewById(R.id.card_current_weather);

        // Set Click Listener
        cardCurrentWeather.setOnClickListener(view -> {
            if (weatherData != null) {
                Intent intent = new Intent(SearchResultsActivity.this, DetailedWeatherActivity.class);

                // Pass city, state, and weather data to DetailedWeatherActivity
                intent.putExtra("city", city);
                intent.putExtra("state", state);
                intent.putExtra("weatherData", weatherData.toString());
                startActivity(intent);
            } else {
                Toast.makeText(this, "Weather data is not available yet.", Toast.LENGTH_SHORT).show();
            }
        });

        if (city != null && state != null) {
            Log.d(TAG, "City: " + city + ", State: " + state);
            fetchWeatherData(city, state);
        }
    }

    private void checkIfFavorite() {
        // Call backend to check if the city is in favorites
        String url = FAVORITES_URL + "/favorites";
        RequestQueue queue = Volley.newRequestQueue(this);

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null,
                response -> {
                    try {
                        for (int i = 0; i < response.length(); i++) {
                            JSONObject favorite = response.getJSONObject(i);
                            String favoriteCity = favorite.getString("city");
                            String favoriteState = favorite.getString("state");

                            if (city.equals(favoriteCity) && state.equals(favoriteState)) {
                                isFavorite = true;
                                break;
                            }
                        }
                        updateFabIcon(); // Update FAB icon after checking
                    } catch (Exception e) {
                        Log.e(TAG, "Error checking favorites: " + e.getMessage());
                    }
                },
                error -> Log.e(TAG, "Error fetching favorites: " + error.getMessage()));

        queue.add(jsonArrayRequest);
    }

    // Add to Favorites
    private void addToFavorites() {
        String url = FAVORITES_URL + "/add_favorite";
        JSONObject body = new JSONObject();
        try {
            body.put("city", city);
            body.put("state", state);
        } catch (Exception e) {
            Log.e(TAG, "Error creating JSON body: " + e.getMessage());
        }

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, body,
                response -> Log.d(TAG, city + " was added to favorites."),
                error -> {
                    Log.e(TAG, "Error adding to favorites: " + error.getMessage());
                    Toast.makeText(this, "Failed to add favorite.", Toast.LENGTH_SHORT).show();
                });

        Volley.newRequestQueue(this).add(jsonObjectRequest);
    }

    // Remove from Favorites
    private void removeFromFavorites() {
        new Thread(() -> {
            String url = FAVORITES_URL + "/delete_favorite";
            HttpURLConnection connection = null;

            try {
                // Create the JSON body
                JSONObject body = new JSONObject();
                body.put("city", city);
                body.put("state", state);
                Log.d(TAG, "Request Body: " + body.toString());

                // Open the connection
                URL requestUrl = new URL(url);
                connection = (HttpURLConnection) requestUrl.openConnection();
                connection.setRequestMethod("DELETE");
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json");

                // Write the body to the output stream
                try (OutputStream os = connection.getOutputStream()) {
                    byte[] input = body.toString().getBytes("UTF-8");
                    os.write(input, 0, input.length);
                }

                // Read the response code
                int responseCode = connection.getResponseCode();
                Log.d(TAG, "Response Code: " + responseCode);

                if (responseCode == HttpURLConnection.HTTP_OK) {
                    Log.d(TAG, city + " was removed from favorites.");
                    runOnUiThread(() -> Toast.makeText(this, city + " removed from favorites", Toast.LENGTH_SHORT).show());
                } else {
                    Log.e(TAG, "Failed to remove favorite. Response Code: " + responseCode);
                    runOnUiThread(() -> Toast.makeText(this, "Failed to remove favorite.", Toast.LENGTH_SHORT).show());
                }
            } catch (Exception e) {
                Log.e(TAG, "Error removing favorite: " + e.getMessage());
                runOnUiThread(() -> Toast.makeText(this, "Failed to remove favorite. Please try again.", Toast.LENGTH_SHORT).show());
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }
        }).start();
    }

    private void updateFabIcon() {
        if (isFavorite) {
            fabFavorite.setImageResource(R.drawable.map_marker_minus);
        } else {
            fabFavorite.setImageResource(R.drawable.map_marker_plus);
        }
    }


    private void fetchWeatherData(String city, String state) {
        // Construct the backend URL
        String url = BACKEND_URL + "?city=" + city + "&state=" + state;

        // Show the progress bar with a message
        showProgressBar("Fetching Weather...");

        // Make the backend call using Volley
        RequestQueue queue = Volley.newRequestQueue(this);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    Log.d(TAG, "Weather Data: " + response.toString());

                    // Save the weather data locally
                    weatherData = response;

                    // Update the UI with parsed data
                    parseAndDisplayCurrentWeather(response);
                    parseAndDisplayWeatherMetrics(response);
                    parseAndDisplayForecast(response);

                    // Update the city and state in Card 1
                    TextView cityTextView = findViewById(R.id.card_current_weather_city);
                    if (city != null && state != null) {
                        cityTextView.setText(city + ", " + state);
                    } else {
                        cityTextView.setText("Unknown Location");
                    }

                    // Log the weather data for debugging purposes
                    Log.d(TAG, "Weather data fetched and saved: " + response.toString());

                    // Hide the progress bar
                    hideProgressBar();
                },
                error -> {
                    Log.e(TAG, "Error fetching weather data: " + error.getMessage());
                    Toast.makeText(this, "Failed to fetch weather data. Please try again.", Toast.LENGTH_SHORT).show();

                    // Hide the progress bar even on error
                    hideProgressBar();
                });

        queue.add(jsonObjectRequest);
    }

    private void parseAndDisplayCurrentWeather(JSONObject response) {
        // Reuse the method from HomeActivity
        try {
            JSONObject currentWeather = response.getJSONObject("data").getJSONArray("timelines")
                    .getJSONObject(0).getJSONArray("intervals").getJSONObject(0).getJSONObject("values");

            // Extract required data
            int temperature = Math.round((float) currentWeather.getDouble("temperature"));
            int weatherCode = currentWeather.getInt("weatherCode");
            String summary = getWeatherDescription(weatherCode);

            // Update Card 1 UI elements
            TextView cityTextView = findViewById(R.id.card_current_weather_city);
            TextView tempTextView = findViewById(R.id.card_current_weather_temp);
            TextView summaryTextView = findViewById(R.id.card_current_weather_summary);
            ImageView weatherIcon = findViewById(R.id.card_current_weather_icon);

            cityTextView.setText(city + ", " + state);
            tempTextView.setText(temperature + "°F");
            summaryTextView.setText(summary);
            weatherIcon.setImageResource(getIconResource(weatherCode));
        } catch (Exception e) {
            Log.e(TAG, "Error parsing weather data: " + e.getMessage());
        }
    }
    private String getWeatherDescription(int weatherCode) {
        switch (weatherCode) {
            case 1000: return "Clear";
            case 1001: return "Cloudy";
            case 1100: return "Mostly Clear";
            case 1101: return "Partly Cloudy";
            case 1102: return "Mostly Cloudy";
            case 2000: return "Fog";
            case 2100: return "Light Fog";
            case 3000: return "Light Wind";
            case 3001: return "Windy";
            case 3002: return "Strong Wind";
            case 4000: return "Drizzle";
            case 4200: return "Light Rain";
            case 4001: return "Rain";
            case 4201: return "Heavy Rain";
            case 5000: return "Snow";
            case 5100: return "Light Snow";
            case 5001: return "Flurries";
            case 5101: return "Heavy Snow";
            case 6000: return "Freezing Drizzle";
            case 6001: return "Freezing Rain";
            case 6200: return "Light Freezing Rain";
            case 6201: return "Heavy Freezing Rain";
            case 7000: return "Ice Pellets";
            case 7101: return "Heavy Ice Pellets";
            case 7102: return "Light Ice Pellets";
            case 8000: return "Thunderstorm";
            default: return "Unknown";
        }
    }
    private int getIconResource(int weatherCode) {
        switch (weatherCode) {
            case 1000: return R.drawable.clear_day;
            case 1001: return R.drawable.cloudy;
            case 1100: return R.drawable.mostly_clear_day;
            case 1101: return R.drawable.partly_cloudy_day;
            case 1102: return R.drawable.mostly_cloudy;
            case 2000: return R.drawable.fog;
            case 2100: return R.drawable.fog_light;
            case 3000: return R.drawable.wind_light;
            case 3001: return R.drawable.wind;
            case 3002: return R.drawable.wind_strong;
            case 4000: return R.drawable.drizzle;
            case 4200: return R.drawable.rain_light;
            case 4001: return R.drawable.rain;
            case 4201: return R.drawable.rain_heavy;
            case 5000: return R.drawable.snow;
            case 5100: return R.drawable.snow_light;
            case 5001: return R.drawable.flurries;
            case 5101: return R.drawable.snow_heavy;
            case 6000: return R.drawable.freezing_drizzle;
            case 6001: return R.drawable.freezing_rain;
            case 6200: return R.drawable.freezing_rain_light;
            case 6201: return R.drawable.freezing_rain_heavy;
            case 7000: return R.drawable.ice_pellets;
            case 7101: return R.drawable.ice_pellets_heavy;
            case 7102: return R.drawable.ice_pellets_light;
            case 8000: return R.drawable.tstorm;
            default: return R.drawable.clear_day;
        }
    }



    private void parseAndDisplayWeatherMetrics(JSONObject response) {
        // Reuse the method from HomeActivity
        try {
            JSONObject currentWeather = response.getJSONObject("data").getJSONArray("timelines")
                    .getJSONObject(0).getJSONArray("intervals").getJSONObject(0).getJSONObject("values");

            // Extract weather metrics
            double humidityFraction = currentWeather.getDouble("humidity");
            double windSpeed = currentWeather.getDouble("windSpeed");
            double visibility = currentWeather.getDouble("visibility");
            double pressure = currentWeather.getDouble("pressureSeaLevel");

            // Convert humidity to percentage
            int humidityPercentage = (int) Math.round(humidityFraction);

            // Round other values to 2 decimal places
            String windSpeedFormatted = String.format("%.2f mph", windSpeed);
            String visibilityFormatted = String.format("%.2f mi", visibility);
            String pressureFormatted = String.format("%.2f inHg", pressure);

            // Update UI
            TextView humidityValue = findViewById(R.id.value_humidity);
            TextView windSpeedValue = findViewById(R.id.value_wind_speed);
            TextView visibilityValue = findViewById(R.id.value_visibility);
            TextView pressureValue = findViewById(R.id.value_pressure);

            humidityValue.setText(humidityPercentage + "%");
            windSpeedValue.setText(windSpeedFormatted);
            visibilityValue.setText(visibilityFormatted);
            pressureValue.setText(pressureFormatted);
        } catch (Exception e) {
            Log.e(TAG, "Error parsing weather metrics: " + e.getMessage());
        }
    }

    private void parseAndDisplayForecast(JSONObject response) {
        // Reuse the method from HomeActivity
        try {
            JSONArray dailyIntervals = response.getJSONObject("data").getJSONArray("timelines")
                    .getJSONObject(0).getJSONArray("intervals");

            LinearLayout forecastTable = findViewById(R.id.forecast_table);
            forecastTable.removeAllViews(); // Clear existing rows

            for (int i = 0; i < Math.min(dailyIntervals.length(), 7); i++) {
                JSONObject interval = dailyIntervals.getJSONObject(i);
                JSONObject values = interval.getJSONObject("values");
                String date = interval.getString("startTime").split("T")[0];
                int weatherCode = values.getInt("weatherCode");
                int tempLow = Math.round((float) values.getDouble("temperatureMin"));
                int tempHigh = Math.round((float) values.getDouble("temperatureMax"));

                addForecastRow(forecastTable, date, weatherCode, tempLow, tempHigh);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error parsing forecast data: " + e.getMessage());
        }
    }
    private void addForecastRow(LinearLayout table, String date, int weatherCode, int tempLow, int tempHigh) {
        LinearLayout rowContainer = new LinearLayout(this);
        rowContainer.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        rowContainer.setPadding(0, 8, 0, 8);
        rowContainer.setBackgroundColor(Color.parseColor("#2d2d2d"));

        LinearLayout row = new LinearLayout(this);
        LinearLayout.LayoutParams rowLayoutParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        row.setLayoutParams(rowLayoutParams);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(16, 16, 16, 16);
        row.setBackgroundColor(Color.parseColor("#1E1E1E"));
        row.setGravity(Gravity.CENTER_VERTICAL);

        TextView dateView = new TextView(this);
        dateView.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 2));
        dateView.setText(date);
        dateView.setTextColor(getResources().getColor(android.R.color.white));
        dateView.setTextSize(14);
        row.addView(dateView);

        ImageView weatherIcon = new ImageView(this);
        weatherIcon.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        weatherIcon.setImageResource(getIconResource(weatherCode));
        row.addView(weatherIcon);

        TextView minTempView = new TextView(this);
        minTempView.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        minTempView.setText(tempLow + "°F");
        minTempView.setTextColor(getResources().getColor(android.R.color.white));
        minTempView.setTextSize(14);
        minTempView.setGravity(Gravity.CENTER);
        row.addView(minTempView);

        TextView maxTempView = new TextView(this);
        maxTempView.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        maxTempView.setText(tempHigh + "°F");
        maxTempView.setTextColor(getResources().getColor(android.R.color.white));
        maxTempView.setTextSize(14);
        maxTempView.setGravity(Gravity.CENTER);
        row.addView(maxTempView);

        rowContainer.addView(row);
        table.addView(rowContainer);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    // Show ProgressBar and hide main content
    private void showProgressBar(String message) {
        LinearLayout progressBarContainer = findViewById(R.id.progress_bar_container);
        TextView progressBarText = findViewById(R.id.progress_bar_text);
        LinearLayout mainContent = findViewById(R.id.main_content);

        progressBarText.setText(message);
        progressBarContainer.setVisibility(View.VISIBLE);
        mainContent.setVisibility(View.GONE);
    }

    // Hide ProgressBar and show main content
    private void hideProgressBar() {
        LinearLayout progressBarContainer = findViewById(R.id.progress_bar_container);
        LinearLayout mainContent = findViewById(R.id.main_content);

        progressBarContainer.setVisibility(View.GONE);
        mainContent.setVisibility(View.VISIBLE);
    }



}


