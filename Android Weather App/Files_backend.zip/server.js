console.log("Starting server...");
const GOOGLE_API_KEY = process.env.GOOGLE_API_KEY;  
const TOMORROW_API_KEY = process.env.TOMORROW_API_KEY;  
const MONGO_DB_PASSWORD = process.env.MONGO_DB_PASSWORD;

const cors = require('cors');
const express = require('express');
const axios = require('axios');
const { MongoClient } = require('mongodb');
const app = express();

const PORT = process.env.PORT || 8080;

// Enable CORS for all origins
app.use(cors());  
app.use(express.json()); 

// MongoDB setup
//const MONGO_URI = `mongodb+srv://adityadutta213:${MONGO_DB_PASSWORD}@cluster0.kgpvu.mongodb.net/HW3?retryWrites=true&w=majority`;
const MONGO_URI = `mongodb+srv://adityadutta213:%40LeonKennedy21@cluster0.kgpvu.mongodb.net/HW3?retryWrites=true&w=majority`;
const client = new MongoClient(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });
let favoritesCollection;

async function connectToMongo() {
    try {
        await client.connect();
        const db = client.db("HW3");
        favoritesCollection = db.collection("favorites");
        console.log("Connected to MongoDB");
    } catch (error) {
        console.error("MongoDB connection error:", error);
    }
}

// Call the function to connect to MongoDB
connectToMongo();

// Google Places Proxy Route
app.get('/proxy', async (req, res) => {
    const { input } = req.query;
    if (!input) {
      return res.status(400).send('Input query parameter is required');
    }
  
    const apiKey = process.env.GOOGLE_API_KEY;  
    const url = `https://maps.googleapis.com/maps/api/place/autocomplete/json?input=${input}&types=(cities)&key=${process.env.PLACES_API_KEY}`;
  
    try {
      const response = await axios.get(url);
      res.set('Access-Control-Allow-Origin', '*');
      res.status(response.status).send(response.data);
    } catch (error) {
      res.status(500).send(`Error: ${error.message}`);
    }
});
  

// Basic route to test the server
app.get('/', (req, res) => {
    res.send('Weather backend is running');
});

// Route for fetching weather data
app.get('/get_weather', async (req, res) => {
    const city = req.query.city;
    const state = req.query.state;

    if (!city || !state) {
        return res.status(400).json({ error: 'Missing location details' });
    }

    try {
        // Call Google Geocode API to get latitude and longitude
        const geocodeUrl = `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(city)},${encodeURIComponent(state)}&key=${process.env.GEOCODING_API_KEY}`;
        const geocodeResponse = await axios.get(geocodeUrl);

        if (!geocodeResponse.data.results || geocodeResponse.data.results.length === 0) {
            return res.status(400).json({ error: 'Invalid location' });
        }

        const lat = geocodeResponse.data.results[0].geometry.location.lat;
        const lon = geocodeResponse.data.results[0].geometry.location.lng;

        //  Call Tomorrow.io API to get weather information
        const weatherUrl = `https://api.tomorrow.io/v4/timelines?location=${lat},${lon}&fields=temperature,temperatureApparent,humidity,pressureSeaLevel,windSpeed,windDirection,visibility,cloudCover,uvIndex,temperatureMax,temperatureMin,weatherCode,sunriseTime,sunsetTime,precipitationProbability,precipitationType&timesteps=1d,1h&units=imperial&apikey=${TOMORROW_API_KEY}`;
        const weatherResponse = await axios.get(weatherUrl);

        if (weatherResponse.status !== 200) {
            return res.status(500).json({ error: 'Failed to fetch weather data from Tomorrow.io' });
        }

        // Return the weather data to the client
        res.json({
            ...weatherResponse.data,
            lat: lat,
            lon: lon
        });

    } catch (error) {
        console.error("Error fetching weather data:", error);
        res.status(500).json({ error: 'An error occurred while fetching weather data' });
    }
});

// Route to add a city to favorites
app.post('/add_favorite', async (req, res) => {
    const { city, state } = req.body;

    if (!city || !state) {
        return res.status(400).json({ error: 'City and state are required' });
    }

    try {
        const result = await favoritesCollection.insertOne({ city, state });
        console.log('Add favorite result:', result);  
        res.status(201).json({ message: 'Favorite added successfully', result });
    } catch (error) {
        console.error("Error adding favorite:", error);
        res.status(500).json({ error: 'Failed to add favorite' });
    }
});

// Route to get all favorite cities
app.get('/favorites', async (req, res) => {
    try {
        const favorites = await favoritesCollection.find().toArray();
        res.status(200).json(favorites);
    } catch (error) {
        console.error("Error fetching favorites:", error);
        res.status(500).json({ error: 'Failed to fetch favorites' });
    }
});

// Route to delete a favorite city
app.delete('/delete_favorite', async (req, res) => {
    const { city, state } = req.body;

    if (!city || !state) {
        return res.status(400).json({ error: 'City and state are required' });
    }

    try {
        const result = await favoritesCollection.deleteOne({ city, state });
        if (result.deletedCount === 1) {
            res.status(200).json({ message: 'Favorite deleted successfully' });
        } else {
            res.status(404).json({ error: 'Favorite not found' });
        }
    } catch (error) {
        console.error("Error deleting favorite:", error);
        res.status(500).json({ error: 'Failed to delete favorite' });
    }
});


// Start the server
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});

